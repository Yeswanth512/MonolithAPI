# Complete Monolithic App Generator
# Creates ALL files including Products and Orders

# 1. Setup project
dotnet new webapi -n MonolithicApp
dotnet new sln -n MonolithicApp
dotnet sln add MonolithicApp

# 2. Create folders
$folders = @("Controllers", "Models", "Repositories", "Services")
foreach ($folder in $folders) {
    New-Item -Path ".\MonolithicApp\$folder" -ItemType Directory -Force
}

# 3. Program.cs
@"
using MonolithicApp.Repositories;
using MonolithicApp.Services;

var builder = WebApplication.CreateBuilder(args);

// Monolithic configuration
builder.Services.AddControllers();
builder.Services.AddSingleton<IUserRepository, UserRepository>();
builder.Services.AddSingleton<IProductRepository, ProductRepository>();
builder.Services.AddSingleton<IOrderRepository, OrderRepository>();
builder.Services.AddSingleton<IUserService, UserService>();
builder.Services.AddSingleton<IProductService, ProductService>();
builder.Services.AddSingleton<IOrderService, OrderService>();

var app = builder.Build();
app.MapControllers();
app.Run();
"@ | Out-File -FilePath ".\MonolithicApp\Program.cs" -Encoding utf8 -Force

# 4. MODELS
# User.cs
@"
namespace MonolithicApp.Models;

public class User
{
    public string Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public List<Order> Orders { get; set; } = new();
}
"@ | Out-File -FilePath ".\MonolithicApp\Models\User.cs" -Encoding utf8 -Force

# Product.cs
@"
namespace MonolithicApp.Models;

public class Product
{
    public string Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }
    public int Stock { get; set; }
}
"@ | Out-File -FilePath ".\MonolithicApp\Models\Product.cs" -Encoding utf8 -Force

# Order.cs
@"
namespace MonolithicApp.Models;

public class Order
{
    public string Id { get; set; }
    public string UserId { get; set; }
    public User User { get; set; }
    public string ProductId { get; set; }
    public Product Product { get; set; }
    public int Quantity { get; set; }
}
"@ | Out-File -FilePath ".\MonolithicApp\Models\Order.cs" -Encoding utf8 -Force

# 5. REPOSITORIES
# User Repository
@"
using MonolithicApp.Models;

namespace MonolithicApp.Repositories;

public interface IUserRepository
{
    User GetUser(string id);
    void CreateUser(User user);
}

public class UserRepository : IUserRepository
{
    private static readonly List<User> _users = new()
    {
        new User { Id = "1", Name = "John Doe", Email = "john@example.com" },
        new User { Id = "2", Name = "Jane Smith", Email = "jane@example.com" }
    };

    public User GetUser(string id) => _users.FirstOrDefault(u => u.Id == id);
    public void CreateUser(User user) => _users.Add(user);
}
"@ | Out-File -FilePath ".\MonolithicApp\Repositories\UserRepository.cs" -Encoding utf8 -Force

# Product Repository
@"
using MonolithicApp.Models;

namespace MonolithicApp.Repositories;

public interface IProductRepository
{
    Product GetProduct(string id);
    List<Product> GetAllProducts();
}

public class ProductRepository : IProductRepository
{
    private static readonly List<Product> _products = new()
    {
        new Product { Id = "1", Name = "Laptop", Price = 999.99m, Stock = 10 },
        new Product { Id = "2", Name = "Mouse", Price = 19.99m, Stock = 50 }
    };

    public Product GetProduct(string id) => _products.FirstOrDefault(p => p.Id == id);
    public List<Product> GetAllProducts() => _products;
}
"@ | Out-File -FilePath ".\MonolithicApp\Repositories\ProductRepository.cs" -Encoding utf8 -Force

# Order Repository
@"
using MonolithicApp.Models;

namespace MonolithicApp.Repositories;

public interface IOrderRepository
{
    List<Order> GetOrdersByUser(string userId);
    void CreateOrder(Order order);
}

public class OrderRepository : IOrderRepository
{
    private static readonly List<Order> _orders = new()
    {
        new Order { Id = "1", UserId = "1", ProductId = "1", Quantity = 2 },
        new Order { Id = "2", UserId = "1", ProductId = "2", Quantity = 1 }
    };

    public List<Order> GetOrdersByUser(string userId) => 
        _orders.Where(o => o.UserId == userId).ToList();
        
    public void CreateOrder(Order order) => _orders.Add(order);
}
"@ | Out-File -FilePath ".\MonolithicApp\Repositories\OrderRepository.cs" -Encoding utf8 -Force

# 6. SERVICES
# User Service
@"
using MonolithicApp.Models;
using MonolithicApp.Repositories;

namespace MonolithicApp.Services;

public interface IUserService
{
    User GetUser(string id);
    void CreateUser(User user);
}

public class UserService : IUserService
{
    private readonly IUserRepository _userRepository;
    private readonly IOrderRepository _orderRepository;

    public UserService(IUserRepository userRepository, IOrderRepository orderRepository)
    {
        _userRepository = userRepository;
        _orderRepository = orderRepository;
    }

    public User GetUser(string id)
    {
        var user = _userRepository.GetUser(id);
        user.Orders = _orderRepository.GetOrdersByUser(id);
        return user;
    }

    public void CreateUser(User user) => _userRepository.CreateUser(user);
}
"@ | Out-File -FilePath ".\MonolithicApp\Services\UserService.cs" -Encoding utf8 -Force

# Product Service
@"
using MonolithicApp.Models;
using MonolithicApp.Repositories;

namespace MonolithicApp.Services;

public interface IProductService
{
    Product GetProduct(string id);
    List<Product> GetAllProducts();
}

public class ProductService : IProductService
{
    private readonly IProductRepository _productRepository;

    public ProductService(IProductRepository productRepository)
    {
        _productRepository = productRepository;
    }

    public Product GetProduct(string id) => _productRepository.GetProduct(id);
    public List<Product> GetAllProducts() => _productRepository.GetAllProducts();
}
"@ | Out-File -FilePath ".\MonolithicApp\Services\ProductService.cs" -Encoding utf8 -Force

# Order Service
@"
using MonolithicApp.Models;
using MonolithicApp.Repositories;

namespace MonolithicApp.Services;

public interface IOrderService
{
    List<Order> GetOrdersByUser(string userId);
    void CreateOrder(Order order);
}

public class OrderService : IOrderService
{
    private readonly IOrderRepository _orderRepository;
    private readonly IUserRepository _userRepository;
    private readonly IProductRepository _productRepository;

    public OrderService(
        IOrderRepository orderRepository,
        IUserRepository userRepository,
        IProductRepository productRepository)
    {
        _orderRepository = orderRepository;
        _userRepository = userRepository;
        _productRepository = productRepository;
    }

    public List<Order> GetOrdersByUser(string userId) => 
        _orderRepository.GetOrdersByUser(userId);

    public void CreateOrder(Order order)
    {
        _userRepository.GetUser(order.UserId) ?? throw new Exception("User not found");
        _productRepository.GetProduct(order.ProductId) ?? throw new Exception("Product not found");
        _orderRepository.CreateOrder(order);
    }
}
"@ | Out-File -FilePath ".\MonolithicApp\Services\OrderService.cs" -Encoding utf8 -Force

# 7. CONTROLLERS
# UserController.cs
@"
using Microsoft.AspNetCore.Mvc;
using MonolithicApp.Services;
using MonolithicApp.Models;

namespace MonolithicApp.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UserController : ControllerBase
{
    private readonly IUserService _userService;

    public UserController(IUserService userService) => _userService = userService;

    [HttpGet("{id}")]
    public IActionResult Get(string id) => Ok(_userService.GetUser(id));

    [HttpPost]
    public IActionResult Create([FromBody] User user)
    {
        _userService.CreateUser(user);
        return CreatedAtAction(nameof(Get), new { id = user.Id }, user);
    }
}
"@ | Out-File -FilePath ".\MonolithicApp\Controllers\UserController.cs" -Encoding utf8 -Force

# ProductController.cs
@"
using Microsoft.AspNetCore.Mvc;
using MonolithicApp.Services;

namespace MonolithicApp.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductController : ControllerBase
{
    private readonly IProductService _productService;

    public ProductController(IProductService productService) => _productService = productService;

    [HttpGet]
    public IActionResult GetAll() => Ok(_productService.GetAllProducts());

    [HttpGet("{id}")]
    public IActionResult Get(string id) => Ok(_productService.GetProduct(id));
}
"@ | Out-File -FilePath ".\MonolithicApp\Controllers\ProductController.cs" -Encoding utf8 -Force

# OrderController.cs
@"
using Microsoft.AspNetCore.Mvc;
using MonolithicApp.Services;
using MonolithicApp.Models;

namespace MonolithicApp.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrderController : ControllerBase
{
    private readonly IOrderService _orderService;

    public OrderController(IOrderService orderService) => _orderService = orderService;

    [HttpGet("user/{userId}")]
    public IActionResult GetByUser(string userId) => Ok(_orderService.GetOrdersByUser(userId));

    [HttpPost]
    public IActionResult Create([FromBody] Order order)
    {
        _orderService.CreateOrder(order);
        return CreatedAtAction(nameof(GetByUser), new { userId = order.UserId }, order);
    }
}
"@ | Out-File -FilePath ".\MonolithicApp\Controllers\OrderController.cs" -Encoding utf8 -Force

Write-Host "Monolithic App created successfully with ALL components!"
Write-Host "Project includes:"
Write-Host "- 3 Controllers (User, Product, Order)"
Write-Host "- 3 Models (User, Product, Order)"
Write-Host "- 3 Services with interfaces"
Write-Host "- 3 Repositories with interfaces"
Write-Host "Run with: cd MonolithicApp && dotnet run"
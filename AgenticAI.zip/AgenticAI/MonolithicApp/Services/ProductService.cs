﻿using MonolithicApp.Models;
using MonolithicApp.Repositories;

namespace MonolithicApp.Services;

public interface IProductService
{
    Product GetProduct(string id);
    List<Product> GetAllProducts();
}

public class ProductService : IProductService
{
    private readonly IProductRepository _productRepository;

    public ProductService(IProductRepository productRepository)
    {
        _productRepository = productRepository;
    }

    public Product GetProduct(string id) => _productRepository.GetProduct(id);
    public List<Product> GetAllProducts() => _productRepository.GetAllProducts();
}

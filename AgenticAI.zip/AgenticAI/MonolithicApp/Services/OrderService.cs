﻿using MonolithicApp.Models;
using MonolithicApp.Repositories;

namespace MonolithicApp.Services;

public interface IOrderService
{
    List<Order> GetOrdersByUser(string userId);
    void CreateOrder(Order order);
}

public class OrderService : IOrderService
{
    private readonly IOrderRepository _orderRepository;
    private readonly IUserRepository _userRepository;
    private readonly IProductRepository _productRepository;

    public OrderService(
        IOrderRepository orderRepository,
        IUserRepository userRepository,
        IProductRepository productRepository)
    {
        _orderRepository = orderRepository;
        _userRepository = userRepository;
        _productRepository = productRepository;
    }

    public List<Order> GetOrdersByUser(string userId) => 
        _orderRepository.GetOrdersByUser(userId);

    public void CreateOrder(Order order)
    {
       var user= _userRepository.GetUser(order.UserId) ?? throw new Exception("User not found");
       var product= _productRepository.GetProduct(order.ProductId) ?? throw new Exception("Product not found");
        _orderRepository.CreateOrder(order);
    }
}

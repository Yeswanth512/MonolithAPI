﻿using MonolithicApp.Models;
using MonolithicApp.Repositories;

namespace MonolithicApp.Services;

public interface IUserService
{
    User GetUser(string id);
    void CreateUser(User user);
}

public class UserService : IUserService
{
    private readonly IUserRepository _userRepository;
    private readonly IOrderRepository _orderRepository;

    public UserService(IUserRepository userRepository, IOrderRepository orderRepository)
    {
        _userRepository = userRepository;
        _orderRepository = orderRepository;
    }

    public User GetUser(string id)
    {
        var user = _userRepository.GetUser(id);
        user.Orders = _orderRepository.GetOrdersByUser(id);
        return user;
    }

    public void CreateUser(User user) => _userRepository.CreateUser(user);
}

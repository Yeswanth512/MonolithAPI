﻿using Microsoft.AspNetCore.Mvc;
using MonolithicApp.Services;

namespace MonolithicApp.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductController : ControllerBase
{
    private readonly IProductService _productService;

    public ProductController(IProductService productService) => _productService = productService;

    [HttpGet]
    public IActionResult GetAll() => Ok(_productService.GetAllProducts());

    [HttpGet("{id}")]
    public IActionResult Get(string id) => Ok(_productService.GetProduct(id));
}

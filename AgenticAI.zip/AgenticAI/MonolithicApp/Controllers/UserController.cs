﻿using Microsoft.AspNetCore.Mvc;
using MonolithicApp.Services;
using MonolithicApp.Models;

namespace MonolithicApp.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UserController : ControllerBase
{
    private readonly IUserService _userService;

    public UserController(IUserService userService) => _userService = userService;

    [HttpGet("{id}")]
    public IActionResult Get(string id) => Ok(_userService.GetUser(id));

    [HttpPost]
    public IActionResult Create([FromBody] User user)
    {
        _userService.CreateUser(user);
        return CreatedAtAction(nameof(Get), new { id = user.Id }, user);
    }
}

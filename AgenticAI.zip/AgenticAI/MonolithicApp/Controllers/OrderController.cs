﻿using Microsoft.AspNetCore.Mvc;
using MonolithicApp.Services;
using MonolithicApp.Models;

namespace MonolithicApp.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrderController : ControllerBase
{
    private readonly IOrderService _orderService;

    public OrderController(IOrderService orderService) => _orderService = orderService;

    [HttpGet("user/{userId}")]
    public IActionResult GetByUser(string userId) => Ok(_orderService.GetOrdersByUser(userId));

    [HttpPost]
    public IActionResult Create([FromBody] Order order)
    {
        _orderService.CreateOrder(order);
        return CreatedAtAction(nameof(GetByUser), new { userId = order.UserId }, order);
    }
}

﻿using MonolithicApp.Models;

namespace MonolithicApp.Repositories;

public interface IProductRepository
{
    Product GetProduct(string id);
    List<Product> GetAllProducts();
}

public class ProductRepository : IProductRepository
{
    private static readonly List<Product> _products = new()
    {
        new Product { Id = "1", Name = "Laptop", Price = 999.99m, Stock = 10 },
        new Product { Id = "2", Name = "Mouse", Price = 19.99m, Stock = 50 }
    };

    public Product GetProduct(string id) => _products.FirstOrDefault(p => p.Id == id);
    public List<Product> GetAllProducts() => _products;
}

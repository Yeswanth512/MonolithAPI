﻿using MonolithicApp.Models;

namespace MonolithicApp.Repositories;

public interface IOrderRepository
{
    List<Order> GetOrdersByUser(string userId);
    void CreateOrder(Order order);
}

public class OrderRepository : IOrderRepository
{
    private static readonly List<Order> _orders = new()
    {
        new Order { Id = "1", UserId = "1", ProductId = "1", Quantity = 2 },
        new Order { Id = "2", UserId = "1", ProductId = "2", Quantity = 1 }
    };

    public List<Order> GetOrdersByUser(string userId) => 
        _orders.Where(o => o.UserId == userId).ToList();
        
    public void CreateOrder(Order order) => _orders.Add(order);
}

﻿using MonolithicApp.Models;

namespace MonolithicApp.Repositories;

public interface IUserRepository
{
    User GetUser(string id);
    void CreateUser(User user);
}

public class UserRepository : IUserRepository
{
    private static readonly List<User> _users = new()
    {
        new User { Id = "1", Name = "John Doe", Email = "john@example.com" },
        new User { Id = "2", Name = "Jane Smith", Email = "jane@example.com" }
    };

    public User GetUser(string id) => _users.FirstOrDefault(u => u.Id == id);
    public void CreateUser(User user) => _users.Add(user);
}
